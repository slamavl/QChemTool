from pyscf.mrpt import nevpt2
from pyscf.mrpt.nevpt2 import NEVPT

#TODO: remove it in future release
from pyscf.mrpt.nevpt2 import sc_nevpt
NEVPT2 = sc_nevpt

