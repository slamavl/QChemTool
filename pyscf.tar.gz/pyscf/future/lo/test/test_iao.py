#!/usr/bin/env python

import unittest
from functools import reduce
import numpy
from pyscf import gto
from pyscf import scf
from pyscf.lo import iao

class KnowValues(unittest.TestCase):
    pass


if __name__ == "__main__":
    print("TODO: Test iao")
    unittest.main()



