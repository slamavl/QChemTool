/*
 * Author: Qiming Sun <osirpt.sun@gmail.com>
 *
 * auxe2: (ij|P) where P is the auxiliary basis
 */

#include <stdlib.h>
#include <assert.h>
#include "cint.h"
#include "vhf/fblas.h"
#include "ao2mo/nr_ao2mo.h"

#define NCTRMAX         72
#define MAX(I,J)        ((I) > (J) ? (I) : (J))
#define OUTPUTIJ        1
#define INPUT_IJ        2

/*
 * (ij| are stored in C-order
 */
static void dcopy_s1(double *out, double *in, int comp,
                     int nj, int nij, int nijk, int di, int dj, int dk)
{
        const size_t dij = di * dj;
        int i, j, k, ic;
        double *pout, *pin;
        for (ic = 0; ic < comp; ic++) {
                for (k = 0; k < dk; k++) {
                        pout = out + k * nij;
                        pin  = in  + k * dij;
                        for (i = 0; i < di; i++) {
                        for (j = 0; j < dj; j++) {
                                pout[i*nj+j] = pin[j*di+i];
                        } }
                }
                out += nijk;
                in  += dij * dk;
        }
}
void RInr3c_fill_s1(int (*intor)(), double *out, int comp,
                    int ish, int jsh, double *buf,
                    int *shls_slice, int *ao_loc, CINTOpt *cintopt,
                    int *atm, int natm, int *bas, int nbas, double *env)
{
        const int ish0 = shls_slice[0];
        const int ish1 = shls_slice[1];
        const int jsh0 = shls_slice[2];
        const int jsh1 = shls_slice[3];
        const int ksh0 = shls_slice[4];
        const int ksh1 = shls_slice[5];
        const size_t naoi = ao_loc[ish1] - ao_loc[ish0];
        const size_t naoj = ao_loc[jsh1] - ao_loc[jsh0];
        const size_t naok = ao_loc[ksh1] - ao_loc[ksh0];
        const size_t nij = naoi * naoj;
        const size_t nijk = nij * naok;

        ish += ish0;
        jsh += jsh0;
        const int di = ao_loc[ish+1] - ao_loc[ish];
        const int dj = ao_loc[jsh+1] - ao_loc[jsh];
        const int ip = ao_loc[ish] - ao_loc[ish0];
        const int jp = ao_loc[jsh] - ao_loc[jsh0];
        out += ip * naoj + jp;

        int ksh, dk, k0;
        int shls[3];

        shls[0] = ish;
        shls[1] = jsh;

        for (ksh = ksh0; ksh < ksh1; ksh++) {
                shls[2] = ksh;
                dk = ao_loc[ksh+1] - ao_loc[ksh];
                k0 = ao_loc[ksh  ] - ao_loc[ksh0];
                (*intor)(buf, shls, atm, natm, bas, nbas, env, cintopt);
                dcopy_s1(out+k0*nij, buf, comp, naoj, nij, nijk, di, dj, dk);
        }
}



/*
 * transform bra, s1 to label AO symmetry
 */
int RIhalfmmm_nr_s1_bra(double *vout, double *vin, double *buf,
                        struct _AO2MOEnvs *envs, int seekdim)
{
        switch (seekdim) {
                case 1: return envs->bra_count * envs->nao;
                case 2: return envs->nao * envs->nao;
        }
        const double D0 = 0;
        const double D1 = 1;
        const char TRANS_N = 'N';
        int nao = envs->nao;
        int i_start = envs->bra_start;
        int i_count = envs->bra_count;
        double *mo_coeff = envs->mo_coeff;

        dgemm_(&TRANS_N, &TRANS_N, &nao, &i_count, &nao,
               &D1, vin, &nao, mo_coeff+i_start*nao, &nao,
               &D0, vout, &nao);
        return 0;
}

/*
 * transform ket, s1 to label AO symmetry
 */
int RIhalfmmm_nr_s1_ket(double *vout, double *vin, double *buf,
                        struct _AO2MOEnvs *envs, int seekdim)
{
        switch (seekdim) {
                case OUTPUTIJ: return envs->nao * envs->ket_count;
                case INPUT_IJ: return envs->nao * envs->nao;
        }
        const double D0 = 0;
        const double D1 = 1;
        const char TRANS_T = 'T';
        const char TRANS_N = 'N';
        int nao = envs->nao;
        int j_start = envs->ket_start;
        int j_count = envs->ket_count;
        double *mo_coeff = envs->mo_coeff;

        dgemm_(&TRANS_T, &TRANS_N, &j_count, &nao, &nao,
               &D1, mo_coeff+j_start*nao, &nao, vin, &nao,
               &D0, vout, &j_count);
        return 0;
}

/*
 * transform bra, s2 to label AO symmetry
 */
int RIhalfmmm_nr_s2_bra(double *vout, double *vin, double *buf,
                        struct _AO2MOEnvs *envs, int seekdim)
{
        switch (seekdim) {
                case OUTPUTIJ: return envs->bra_count * envs->nao;
                case INPUT_IJ: return envs->nao * (envs->nao+1) / 2;
        }
        const double D0 = 0;
        const double D1 = 1;
        const char SIDE_L = 'L';
        const char UPLO_U = 'U';
        int nao = envs->nao;
        int i_start = envs->bra_start;
        int i_count = envs->bra_count;
        double *mo_coeff = envs->mo_coeff;

        dsymm_(&SIDE_L, &UPLO_U, &nao, &i_count,
               &D1, vin, &nao, mo_coeff+i_start*nao, &nao,
               &D0, vout, &nao);
        return 0;
}

/*
 * transform ket, s2 to label AO symmetry
 */
int RIhalfmmm_nr_s2_ket(double *vout, double *vin, double *buf,
                        struct _AO2MOEnvs *envs, int seekdim)
{
        switch (seekdim) {
                case OUTPUTIJ: return envs->nao * envs->ket_count;
                case INPUT_IJ: return envs->nao * (envs->nao+1) / 2;
        }
        const double D0 = 0;
        const double D1 = 1;
        const char SIDE_L = 'L';
        const char UPLO_U = 'U';
        int nao = envs->nao;
        int j_start = envs->ket_start;
        int j_count = envs->ket_count;
        double *mo_coeff = envs->mo_coeff;
        int i, j;

        dsymm_(&SIDE_L, &UPLO_U, &nao, &j_count,
               &D1, vin, &nao, mo_coeff+j_start*nao, &nao,
               &D0, buf, &nao);
        for (j = 0; j < nao; j++) {
                for (i = 0; i < j_count; i++) {
                        vout[i] = buf[i*nao+j];
                }
                vout += j_count;
        }
        return 0;
}

/*
 * unpack the AO integrals and copy to vout, s2 to label AO symmetry
 */
int RImmm_nr_s2_copy(double *vout, double *vin, double *buf,
                     struct _AO2MOEnvs *envs, int seekdim)
{
        switch (seekdim) {
                case OUTPUTIJ: return envs->nao * envs->nao;
                case INPUT_IJ: return envs->nao * (envs->nao+1) / 2;
        }
        int nao = envs->nao;
        int i, j;
        for (i = 0; i < nao; i++) {
                for (j = 0; j < i; j++) {
                        vout[i*nao+j] = vin[j];
                        vout[j*nao+i] = vin[j];
                }
                vout[i*nao+i] = vin[i];
                vin += nao;
        }
        return 0;
}

