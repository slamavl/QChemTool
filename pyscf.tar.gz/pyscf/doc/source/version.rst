.. _version:


Version history
***************

===============  ==========
---------------  ----------
1.2 alpha        2016-8-?
1.1_             2016-6-4
1.1 beta         2016-4-11 (feature freeze)
1.1 alpha 2      2016-3-8
1.1 alpha 1      2016-2-8
1.0_             2015-10-7
1.0 rc1          2015-9-7
1.0 beta 1       2015-8-2 (feature freeze)
1.0 alpha 2      2015-7-3
1.0 alpha 1      2015-4-7
===============  ==========

.. _1.1: https://github.com/sunqm/pyscf/tree/1.1
.. _1.0: https://github.com/sunqm/pyscf/tree/1.0
