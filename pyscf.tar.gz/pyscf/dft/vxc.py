import sys
from pyscf.dft.libxc import *
sys.stderr.write('WARN: vxc module was replaced by libxc module since PySCF-1.1\n')
